<?php

include '../config.php';
$id_kamar = $_GET['id_kamar'];

mysqli_query($koneksi, "DELETE FROM tb_tipekamar WHERE id_kamar='$id_kamar'");

header("location: admrooms.php");
?>