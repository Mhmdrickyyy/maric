<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<style>

</style><head>
	<meta charset="utf-8">
	<title>Marian</title>
	<meta name="description" content="">
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- <link rel="shortcut icon" href="img/favicon.png"> -->

	<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet'>

	<!-- Syntax Highlighter -->
	<link rel="stylesheet" type="text/css" href="syntax-highlighter/styles/shCore.css" Mariana="all">
	<link rel="stylesheet" type="text/css" href="syntax-highlighter/styles/shThemeDefault.css" Mariana="all">

	<!-- Font Awesome CSS-->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<!-- Normalize/Reset CSS-->
	<link rel="stylesheet" href="assets/css/normalize.min.css">
	<!-- Main CSS-->
	<link rel="stylesheet" href="assets/css/main.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

</head>

<body id="welcome">


	<aside class="left-sidebar">
		<div class="logo">
			<a href="#">
				<h1>Admin Maric</h1>
			</a>
		</div>
		<nav class="left-nav">
	
		<p>
	
			<ul id="nav">
				<li class="current"><a href="admrooms.php">Data Kamar</a></li>
				<li class="current" ><a href="admfacility.php">Data Fasilitas Hotel</a></li>
				<li class="current" ><a href="logout.php">Logout</a></li>
				
			
				
			</ul>
		</nav>
	</aside>

		<div id="main-wrapper">
		<div class="main-content">
			<section id="welcome">
				<div class="content-header">
					<h1>Data Kamar</h1>
				</div>
					<br>	

	<header>
		<h3 align="center"> Tambah data kamar </h3>
		<br>
		</header>

		<form action = "aksitambah.php" method="POST" align="center">
			<fieldset>
			<input type="hidden" class="form-control" name="id_kamar" value="<?php echo $d['id_kamar']; ?>">
				<p>
					<label for="tipe_kamar">Tipe Kamar : </label>
					<input type="text" name="tipe_kamar" placehorder="Tipe Kamar" required/>
				</p>
				<p>
					<label for="jml_kamar"> Jumlah Kamar : </label>
					<input type="number" name="jml_kamar" required >
				</p>
				<p>
					<label for="harga_kamar">Harga Kamar : </label>
					<input type="text" name="harga_kamar" placehorder="Harga Kamar" required/>
				</p>
				<p>
					<label for="Fasilitas">Fasilitas Kamar : </label>
					<input type="text" name="Fasilitas" required/>
				</p>
				<p>
					<label for="keterangan">Keterangan : </label>
					<textarea type="text" name="keterangan"></textarea>
				</p>
				<p>
					<input type="submit" value="tambah" name="tambah"/>
</p>
</fieldset>
</form>





				<div class="welcome">
					<table class="table1" align="center">
		<tr>
			<th>No</th>
			<th>Tipe Kamar</th>
			<th>Jumlah Kamar</th>
			<th>Harga Kamar</th>
			<th>Fasilitas</th>
			<th>Keterangan</th>
			<th>Aksi</th>
		</tr>
			<tbody>
			<?php
                  include '../config.php';
				 
                  $data = mysqli_query($koneksi, "SELECT * FROM tb_tipekamar");
                  while($d = mysqli_fetch_array($data)){
                    ?>
                  <tr>
                      <td><?php echo $d['id_kamar']; ?></td>
                      <td><?php echo $d['tipe_kamar']; ?></td>
                      <td><?php echo $d['jml_kamar']; ?></td>
                      <td><?php echo $d['harga_kamar']; ?></td>
                      <td><?php echo $d['Fasilitas']; ?></td>
					  <td><?php echo $d['keterangan']; ?></td>
                      <td><a href="editdatakamar.php?id_kamar=<?php echo $d['id_kamar'];?>"> Edit</a>
                      <a href="deleterooms.php?id_kamar=<?php echo $d['id_kamar'];?>" onclick="return confirm('Hapus Data ini?')"> Delete</a>
                    </td>
                  <?php 
                  }
                  ?>
                  
</tbody>
			</table>
		<br>
				</br>






</body>
</html>