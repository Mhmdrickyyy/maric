<!DOCTYPE HTML>
<html>
    <style>
        table{
            border-collapse: collapse;
            width: 80%;
        }
        table, td, th{
            border: 0px solid black;
            text-align: left;
        }
        th{
            background-color: #f0971c;
            color: white;
        }
        td{
            padding: 15px;
            border-bottom: 2px solid #9e9e9e75;
        }
        tr: hover{
            background-color: #9e9e9e3b;
        }
        .ic{
            background-color: #fff;
            border-bottom: none;
            border-top: none;
        }
        .bubu {
      background: white;
    border: 2px solid rgb(209, 209, 209); 
	color: rgb(165, 165, 165);
  align-items: right;
  padding-left: 30px;
  padding-right: 30px;
  padding-top: 5px;
  padding-bottom: 5px;
  border-radius: 40px; 
cursor: pointer;}
    .bubu:hover {
      border: 2px solid transparent;
      background: #f0971c;
      color: #fff; }
	.bubu:focus{
		border: 2px #f0971c;
      background: #f0971c;
      color: #fff;
	}
    </style>
  <head>
  <meta charset="utf-8">
	<title>Marian</title>
	<meta name="description" content="">
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- <link rel="shortcut icon" href="img/favicon.png"> -->

	<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet'>

	<!-- Syntax Highlighter -->
	<link rel="stylesheet" type="text/css" href="syntax-highlighter/styles/shCore.css" Mariana="all">
	<link rel="stylesheet" type="text/css" href="syntax-highlighter/styles/shThemeDefault.css" Mariana="all">

	<!-- Font Awesome CSS-->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<!-- Normalize/Reset CSS-->
	<link rel="stylesheet" href="assets/css/normalize.min.css">
	<!-- Main CSS-->
	<link rel="stylesheet" href="assets/css/main.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

  </head>
  <body id="welcome">
  


<aside class="left-sidebar">
	<div class="logo">
		<a href="#">
			<h1>Admin Maric</h1>
		</a>
	</div>
	<nav class="left-nav">

	<p>

		<ul id="nav">
			<li class="current"><a href="admrooms.php">Data Kamar</a></li>
			<li class="current" ><a href="admfacility.php">Data Fasilitas Hotel</a></li>
			<li class="current" ><a href="logout.php">Logout</a></li>
			
		
			
		</ul>
	</nav>
</aside>

	<div id="main-wrapper">
	<div class="main-content">
		<section id="welcome">
			<div class="content-header">
				<h1>Data Kamar</h1>
			</div>
				<br>	

<header>
	<h3 align = "center"> Edit data kamar </h3>
	</header>

      <div class="col-md-8 ml-center contact-info">
        <?php
         include '../config.php';
        $id_kamar=$_GET['id_kamar'];
         $data = mysqli_query($koneksi, "SELECT * FROM tb_tipekamar WHERE id_kamar='$id_kamar'");
         while($d = mysqli_fetch_array($data)){
           ?>

        <form action="aksieditrooms.php" method="POST">

      <table class="col-md-8 ml-center contact-info">
				<td  class="ic"><input type="hidden" class="form-control" name="id_kamar" value="<?php echo $d['id_kamar']; ?>"></td>
			</tr>
			<tr>
			<td class="ic"><label for="tipe_kamar" class="font-weight-bold">Tipe Kamar</label></td>
				<td  class="ic"><input type="text" class="form-control" name="tipe_kamar" value="<?php echo $d['tipe_kamar']; ?>" required>
			</tr>
      <tr>
			<td class="ic"><label for="jml_kamar" class="font-weight-bold">Jumlah Kamar</label></td>	
      <td class="ic"><input type="number" class="form-control" name="jml_kamar" value="<?php echo $d['jml_kamar'];?>" required></td>
		</tr>
			<tr>
			<td class="ic"><label for="harga_kamar" class="font-weight-bold">Harga Kamar</label></td>
				<td class="ic"><input type="text" class="form-control" name="harga_kamar" value="<?php echo $d['harga_kamar'];?>" required></td>
			</tr>
			<tr>
			<td class="ic"><label for="fasilitas" class="font-weight-bold">Fasilitas</label></td>
				<td class="ic"><textarea type="text" class="form-control" name="Fasilitas" value="<?php echo $d['Fasilitas'];?>" required><?php echo $d['Fasilitas'];?></textarea></td>
			</tr>
			<td class="ic"><label for="keterangan" class="font-weight-bold">Keterangan</label></td>
				<td class="ic"><textarea type="text" class="form-control" name="keterangan" value="<?php echo $d['keterangan'];?>" required><?php echo $d['keterangan'];?></textarea></td>
			</tr>
      <tr>
      <td class="ic"></td>
				<td class="ic"><button type="submit" class="bubu">Edit</button></td>
      </tr>
</table>
<?php
}
?>
</form>

</div>
</section>


  </body>
</html>