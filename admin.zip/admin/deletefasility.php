<?php

include '../config.php';
$id_fasilitas = $_GET['id_fasilitas'];

mysqli_query($koneksi, "DELETE FROM tb_fasilitas WHERE id_fasilitas='$id_fasilitas'");

header("location: admfacility.php");
?>